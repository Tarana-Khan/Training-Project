package com.vsics;

import org.junit.jupiter.api.Test;
import org.springframework.boot.test.context.SpringBootTest;

@SpringBootTest
class SpringBootProductAppusingMvcApplicationTests {

	@Test
	void contextLoads() {
	}

}
