package com.vsics.exception;

public class ProductNotAvailable extends Exception {
	public ProductNotAvailable(String msg) {
		super(msg);
	}

}
