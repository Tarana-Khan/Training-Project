package com.vsics;

import org.springframework.boot.SpringApplication;
import org.springframework.boot.autoconfigure.SpringBootApplication;

@SpringBootApplication
public class SpringBootProductAppusingMvcApplication {

	public static void main(String[] args) {
		SpringApplication.run(SpringBootProductAppusingMvcApplication.class, args);
	}

}
