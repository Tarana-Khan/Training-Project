package com.vsics.entity;

import jakarta.persistence.Entity;
import jakarta.persistence.GeneratedValue;
import jakarta.persistence.GenerationType;
import jakarta.persistence.Id;
import jakarta.persistence.Table;

//This is binding class for form and Entity class as well of Table
@Entity
@Table(name="products")
public class Product {
 @Id //for primary key
 @GeneratedValue(strategy = GenerationType.AUTO)//to generate automatically(id))
 private Integer id;
 private String name;
 private String description;
 private String brand;
 private Long price;
 
 public Product() {
	// TODO Auto-generated constructor stub
}

public Product(Integer id, String name, String description, String brand, Long price) {
	super();
	this.id = id;
	this.name = name;
	this.description = description;
	this.brand = brand;
	this.price = price;
}

public Integer getId() {
	return id;
}

public void setId(Integer id) {
	this.id = id;
}

public String getName() {
	return name;
}

public void setName(String name) {
	this.name = name;
}

public String getDescription() {
	return description;
}

public void setDescription(String description) {
	this.description = description;
}

public String getBrand() {
	return brand;
}

public void setBrand(String brand) {
	this.brand = brand;
}

public Long getPrice() {
	return price;
}

public void setPrice(Long price) {
	this.price = price;
}

@Override
public String toString() {
	return "Product [id=" + id + ", name=" + name + ", description=" + description + ", brand=" + brand + ", price="
			+ price + "]";
}


}
