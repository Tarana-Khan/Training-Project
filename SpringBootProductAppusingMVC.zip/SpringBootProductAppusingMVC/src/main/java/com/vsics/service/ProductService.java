package com.vsics.service;

import java.util.List;
import java.util.Optional;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;
import com.vsics.entity.Product;
import com.vsics.exception.ProductNotAvailable;
import com.vsics.repository.ProductRepository;

@Service
public class ProductService {

	@Autowired
	private ProductRepository productRepository;

// to store product
	public String storeProductRecord(Product product) {
		productRepository.save(product);
		return "datasaved successfully";
	}

//get product by id
	public Product getProductById(Integer integer) throws ProductNotAvailable {
		Optional<Product> optional = productRepository.findById(integer);
		Product product = null;
		if (optional.isPresent()) {
			if (optional.isPresent()) {
				product = optional.get();
			}
			return product;
		} else {
			throw new ProductNotAvailable("ProductNotAvailable ");
		}
	}
	
	  
	  // get all products 
	public List<Product> getProducts() {
	  
	  List<Product> products = (List<Product>) productRepository.findAll();
	  
	  return products; 
	  }
	 

	// delete product by id
	public void deleteProductById(Integer integer) throws ProductNotAvailable {
		Optional<Product> optional = productRepository.findById(integer);
		if (optional.isPresent()) {
			productRepository.deleteById(integer);
		} else {
			throw new ProductNotAvailable("ProductNotAvailable ");
		}
	}
}