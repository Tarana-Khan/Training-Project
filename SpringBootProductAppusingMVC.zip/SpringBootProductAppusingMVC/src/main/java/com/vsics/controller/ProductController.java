package com.vsics.controller;

import org.springframework.stereotype.Controller;

import java.util.List;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.ui.Model;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.ModelAttribute;
import org.springframework.web.bind.annotation.PathVariable;
import org.springframework.web.bind.annotation.PostMapping;
import org.springframework.web.bind.annotation.ResponseBody;

import com.vsics.entity.Product;
import com.vsics.exception.ProductNotAvailable;
import com.vsics.service.ProductService;

@Controller
public class ProductController {

	@Autowired
	private ProductService productService;

	// add product
	@GetMapping("/reg")
	public String addProduct() {

		return "add_product_form";
	}

	// store product
	@PostMapping("/saveProduct")
	public String saveProductData(@ModelAttribute Product product, Model model) {
		model.addAttribute("p1", product);
		productService.storeProductRecord(product);
		return "show_product_data";
	}

	// get product by id
	@GetMapping("/product/{Id}")
	public String findProductById(@PathVariable(name = "Id") Integer integer, Model model) throws ProductNotAvailable {

		Product product = productService.getProductById(integer);
		model.addAttribute("p1", product);
		return "show_product_data";
	}

	@GetMapping("/productList")
	public String findProducts(Model model) {

		List<Product> products = productService.getProducts();
		model.addAttribute("products", products);
		return "Product_List";
	}

	// delete product by id
	@GetMapping("/delete/{Id}")
	@ResponseBody
	public String deletProduct(@PathVariable(name = "Id") Integer integer) throws ProductNotAvailable {
		productService.deleteProductById(integer);
		return "record deleted for " + integer;
	}
}
